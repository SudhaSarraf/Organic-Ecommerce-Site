import Nav from "../components/global/Navbar";
import Footer from "../components/global/Footer";


function Dashboard(){
    return(
        <div className="Dashboard">
            
            <h1>Welcome to Dashboard </h1>
            <Footer/> 
        </div>
    )
}

export default Dashboard;